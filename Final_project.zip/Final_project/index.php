<?php

header('location: view/Login.php')

?>